# ArgoCD Image Updater Helm Chart (CRD-based v1.x)

Helm chart for deploying [ArgoCD Image Updater](https://github.com/argoproj-labs/argocd-image-updater) with first-class Azure Container Registry (ACR) pull secret support.

## Quick Start with ACR on AKS

### Step 1: Create the Service Principal

```bash
chmod +x setup-acr-secret.sh

# Option A: Script creates the K8s secret via kubectl
./setup-acr-secret.sh --acr-name myregistry --create-k8s-secret --namespace argocd

# Option B: Just get the credentials (chart creates the secret)
./setup-acr-secret.sh --acr-name myregistry
```

### Step 2: Install the chart

```bash
# If using Option A (secret already exists):
helm install argocd-image-updater ./argocd-image-updater \
  -n argocd \
  --set acrPullSecret.create=false \
  --set acrPullSecret.name=acr-pull-secret \
  --set acrPullSecret.server=myregistry.azurecr.io

# If using Option B (chart creates the secret):
helm install argocd-image-updater ./argocd-image-updater \
  -n argocd \
  --set acrPullSecret.create=true \
  --set acrPullSecret.server=myregistry.azurecr.io \
  --set acrPullSecret.username=<SP_APP_ID> \
  --set-string acrPullSecret.password=<SP_PASSWORD>
```

### Step 3: Create an ImageUpdater CR

```yaml
apiVersion: argocd-image-updater.argoproj.io/v1alpha1
kind: ImageUpdater
metadata:
  name: my-apps
  namespace: argocd
spec:
  namespace: argocd
  commonUpdateSettings:
    pullSecret: "pullsecret:argocd/acr-pull-secret"
  applicationRefs:
    - namePattern: "my-app"
      images:
        - alias: app
          imageName: myregistry.azurecr.io/myapp:1.0.0
          commonUpdateSettings:
            updateStrategy: semver
          manifestTargets:
            helm:
              name: image.repository
              tag: image.tag
```

## How the pullSecret Reference Works

The `pullSecret` field in the ImageUpdater CR uses this format:

```
pullsecret:<namespace>/<secret-name>
```

This tells the image updater controller to read the `kubernetes.io/dockerconfigjson` secret and use its credentials when querying the registry for tags. The secret must exist in the specified namespace and the controller's ServiceAccount must have `get` permissions on secrets in that namespace (which the chart's RBAC provides).

## pullSecret Precedence

Settings cascade from global → applicationRef → image (most specific wins):

```yaml
spec:
  commonUpdateSettings:
    pullSecret: "pullsecret:argocd/acr-pull-secret"    # 1. Global default
  applicationRefs:
    - namePattern: "my-app"
      commonUpdateSettings:
        pullSecret: "pullsecret:argocd/other-secret"    # 2. Per app-pattern override
      images:
        - alias: special
          commonUpdateSettings:
            pullSecret: "pullsecret:argocd/special-secret" # 3. Per image override
```

## Auto-configured registries.conf

When `registries.autoConfigureACR: true` (default) and `acrPullSecret.server` is set, the chart auto-generates `registries.conf`:

```yaml
registries:
  - name: ACR
    prefix: myregistry.azurecr.io
    api_url: https://myregistry.azurecr.io
    default: true
    credentials: pullsecret:argocd/acr-pull-secret
```

## Security Best Practices

| Practice | Implementation |
|----------|---------------|
| Least privilege | SP gets `AcrPull` role only (read-only, no push) |
| Scoped access | Role assignment scoped to specific ACR, not subscription |
| Secret rotation | SP credentials have a configurable expiry (default 2 years) |
| K8s secret type | Uses `kubernetes.io/dockerconfigjson` (standard docker-registry) |
| RBAC | Controller only has `get/list/watch` on secrets in its namespace |

## Rotating Credentials

```bash
# Reset the SP password
az ad sp credential reset --id <SP_APP_ID> --years 2

# Update the chart
helm upgrade argocd-image-updater ./argocd-image-updater \
  -n argocd \
  --set acrPullSecret.create=true \
  --set-string acrPullSecret.password=<NEW_PASSWORD> \
  ... (other values)
```

## Values Reference

See `values.yaml` for all configurable options. Key ACR-related values:

| Parameter | Description | Default |
|-----------|-------------|---------|
| `acrPullSecret.create` | Create the docker-registry secret | `false` |
| `acrPullSecret.name` | Secret name | `acr-pull-secret` |
| `acrPullSecret.server` | ACR server (e.g. myregistry.azurecr.io) | `""` |
| `acrPullSecret.username` | SP App ID | `""` |
| `acrPullSecret.password` | SP password | `""` |
| `registries.autoConfigureACR` | Auto-generate registries.conf for ACR | `true` |
