#!/usr/bin/env bash
#
# setup-acr-secret.sh
#
# Creates an Azure AD Service Principal with AcrPull role scoped to a
# specific ACR, then either:
#   (a) Creates the K8s docker-registry secret directly, OR
#   (b) Outputs the values to pass to the Helm chart
#
# Best practices applied:
#   - Least privilege: AcrPull role only (read-only, no push)
#   - Scoped to a single ACR (not subscription-wide)
#   - 2-year expiry with reminder to rotate
#   - SP naming convention for easy identification
#
# Usage:
#   ./setup-acr-secret.sh --acr-name myregistry --namespace argocd [--create-k8s-secret]
#
set -euo pipefail

# ─── Defaults ─────────────────────────────────────────────────────────────────
NAMESPACE="argocd"
SECRET_NAME="acr-pull-secret"
CREATE_K8S_SECRET=false
SP_YEARS=2

usage() {
  cat <<EOF
Usage: $0 --acr-name <acr-name> [OPTIONS]

Required:
  --acr-name NAME        Azure Container Registry name (without .azurecr.io)

Options:
  --namespace NS         Kubernetes namespace (default: argocd)
  --secret-name NAME     K8s secret name (default: acr-pull-secret)
  --create-k8s-secret    Also create the K8s secret directly via kubectl
  --sp-years N           Service Principal credential lifetime in years (default: 2)
  -h, --help             Show this help

Examples:
  # Just show the values for Helm:
  $0 --acr-name myregistry

  # Create the K8s secret directly:
  $0 --acr-name myregistry --create-k8s-secret --namespace argocd
EOF
  exit 0
}

# ─── Parse args ───────────────────────────────────────────────────────────────
ACR_NAME=""
while [[ $# -gt 0 ]]; do
  case $1 in
    --acr-name)       ACR_NAME="$2"; shift 2 ;;
    --namespace)      NAMESPACE="$2"; shift 2 ;;
    --secret-name)    SECRET_NAME="$2"; shift 2 ;;
    --create-k8s-secret) CREATE_K8S_SECRET=true; shift ;;
    --sp-years)       SP_YEARS="$2"; shift 2 ;;
    -h|--help)        usage ;;
    *)                echo "Unknown option: $1"; usage ;;
  esac
done

if [[ -z "$ACR_NAME" ]]; then
  echo "ERROR: --acr-name is required"
  usage
fi

ACR_SERVER="${ACR_NAME}.azurecr.io"
SP_NAME="sp-argocd-image-updater-${ACR_NAME}"

# ─── Validate prerequisites ──────────────────────────────────────────────────
echo "Checking prerequisites..."
command -v az >/dev/null 2>&1 || { echo "ERROR: 'az' CLI not found"; exit 1; }
command -v jq >/dev/null 2>&1 || { echo "ERROR: 'jq' not found"; exit 1; }

# Verify logged in
az account show >/dev/null 2>&1 || { echo "ERROR: Not logged in to Azure. Run 'az login' first."; exit 1; }

# ─── Get ACR resource ID ─────────────────────────────────────────────────────
echo "Looking up ACR '${ACR_NAME}'..."
ACR_ID=$(az acr show --name "$ACR_NAME" --query id -o tsv 2>/dev/null) || {
  echo "ERROR: ACR '${ACR_NAME}' not found. Check the name and your subscription."
  exit 1
}
echo "  ACR ID: ${ACR_ID}"

# ─── Check if SP already exists ──────────────────────────────────────────────
EXISTING_SP=$(az ad sp list --display-name "$SP_NAME" --query '[0].appId' -o tsv 2>/dev/null || true)
if [[ -n "$EXISTING_SP" && "$EXISTING_SP" != "None" ]]; then
  echo ""
  echo "WARNING: Service Principal '${SP_NAME}' already exists (appId: ${EXISTING_SP})"
  echo "  Resetting credentials..."
  SP_JSON=$(az ad sp credential reset --id "$EXISTING_SP" --years "$SP_YEARS" -o json)
  SP_APP_ID=$(echo "$SP_JSON" | jq -r .appId)
  SP_PASSWORD=$(echo "$SP_JSON" | jq -r .password)
else
  # ─── Create Service Principal with AcrPull ────────────────────────────────
  echo "Creating Service Principal '${SP_NAME}' with AcrPull role..."
  SP_JSON=$(az ad sp create-for-rbac \
    --name "$SP_NAME" \
    --role AcrPull \
    --scopes "$ACR_ID" \
    --years "$SP_YEARS" \
    -o json)
  SP_APP_ID=$(echo "$SP_JSON" | jq -r .appId)
  SP_PASSWORD=$(echo "$SP_JSON" | jq -r .password)
fi

SP_TENANT=$(echo "$SP_JSON" | jq -r .tenant)

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  Service Principal created successfully"
echo "═══════════════════════════════════════════════════════════════════"
echo "  SP Name:     ${SP_NAME}"
echo "  App ID:      ${SP_APP_ID}"
echo "  Tenant ID:   ${SP_TENANT}"
echo "  ACR Server:  ${ACR_SERVER}"
echo "  Expires in:  ${SP_YEARS} year(s)"
echo "═══════════════════════════════════════════════════════════════════"

# ─── Create K8s secret if requested ──────────────────────────────────────────
if [[ "$CREATE_K8S_SECRET" == "true" ]]; then
  echo ""
  echo "Creating Kubernetes docker-registry secret '${SECRET_NAME}' in namespace '${NAMESPACE}'..."

  command -v kubectl >/dev/null 2>&1 || { echo "ERROR: 'kubectl' not found"; exit 1; }

  # Delete existing secret if present (idempotent)
  kubectl delete secret "$SECRET_NAME" \
    --namespace "$NAMESPACE" \
    --ignore-not-found

  kubectl create secret docker-registry "$SECRET_NAME" \
    --namespace "$NAMESPACE" \
    --docker-server="$ACR_SERVER" \
    --docker-username="$SP_APP_ID" \
    --docker-password="$SP_PASSWORD"

  echo "  Secret '${SECRET_NAME}' created in namespace '${NAMESPACE}'"
fi

# ─── Output Helm values ──────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  Helm install command"
echo "═══════════════════════════════════════════════════════════════════"

if [[ "$CREATE_K8S_SECRET" == "true" ]]; then
  echo ""
  echo "  Secret already created via kubectl. Install the chart WITHOUT"
  echo "  acrPullSecret.create (the chart will reference the existing secret):"
  echo ""
  echo "  helm install argocd-image-updater ./argocd-image-updater \\"
  echo "    --namespace ${NAMESPACE} \\"
  echo "    --set acrPullSecret.create=false \\"
  echo "    --set acrPullSecret.name=${SECRET_NAME} \\"
  echo "    --set acrPullSecret.server=${ACR_SERVER}"
else
  echo ""
  echo "  Let the chart create the secret for you:"
  echo ""
  echo "  helm install argocd-image-updater ./argocd-image-updater \\"
  echo "    --namespace ${NAMESPACE} \\"
  echo "    --set acrPullSecret.create=true \\"
  echo "    --set acrPullSecret.name=${SECRET_NAME} \\"
  echo "    --set acrPullSecret.server=${ACR_SERVER} \\"
  echo "    --set acrPullSecret.username=${SP_APP_ID} \\"
  echo "    --set-string acrPullSecret.password=${SP_PASSWORD}"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  ImageUpdater CR pullSecret reference"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "  In your ImageUpdater CR, use:"
echo "    pullSecret: \"pullsecret:${NAMESPACE}/${SECRET_NAME}\""
echo ""
echo "  Or set it at the global level in the CR:"
echo ""
echo "    spec:"
echo "      commonUpdateSettings:"
echo "        pullSecret: \"pullsecret:${NAMESPACE}/${SECRET_NAME}\""
echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  REMINDER: Credentials expire in ${SP_YEARS} year(s)."
echo "  Rotate with: az ad sp credential reset --id ${SP_APP_ID}"
echo "═══════════════════════════════════════════════════════════════════"
